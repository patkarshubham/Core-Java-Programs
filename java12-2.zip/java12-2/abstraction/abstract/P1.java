class P1
{
  public static void main(String []args)
  {
	new AA();//error
  }
}