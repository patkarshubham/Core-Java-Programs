public class Addition extends Cal
{
  public Addition(int n1,int n2)
  {
	super(n1,n2);
  }
  public void task()
  {
	res=num1+num2;
  }
}