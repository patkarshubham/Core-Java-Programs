class CalUser
{
  public static void main(String []args)
  {
	Cal obj=new Multiplication(4324,464);
	obj.task();
	obj.showResult();
  }
}