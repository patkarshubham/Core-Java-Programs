class BB implements AA
{
  public void method1()
  {
	System.out.println("Method1 called");
  }
  public void method2()
  {
	System.out.println("Method2 called");
  }
}