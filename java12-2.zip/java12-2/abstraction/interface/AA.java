interface AA
{
  void method1();
  void method2();
}



