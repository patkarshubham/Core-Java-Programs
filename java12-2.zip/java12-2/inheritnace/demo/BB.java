public class BB extends AA
{
  public void method3()
  {
	System.out.println("Welcome");
  }
  public static void main(String []args)
  {
	BB obj=new BB();
	obj.method1();
	obj.method2();
	obj.method3();
  }
}