public class AA
{
  public void method1()
  {
	System.out.println("Method1 of class is called");
  }
  public void method2()
  {
	System.out.println("Method2 of class is called");
  }
}