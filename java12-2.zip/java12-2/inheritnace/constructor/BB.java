class AA
{
  public AA()
  {
	System.out.println("Constructor1 of class AA");
  }
  public AA(int x)
  {
	System.out.println("Constructor2 of class AA");
  }
}
class BB extends AA
{
  public BB()
  {
	//super();
	super(30);
	System.out.println("Constructor of class BB");
  }
  public static void main(String []args)
  {
	new BB();
  }
}
