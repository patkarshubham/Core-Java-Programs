public class AA
{
  private int x;
  private int y;
  public AA(int a1,int a2)
  {
	x=a1;
	y=a2;
  }
  public void showData()
  {
	System.out.println(x);
	System.out.println(y);
  }
}