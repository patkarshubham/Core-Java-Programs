public class BB extends AA
{
  private int z;
  public BB(int n1,int n2,int n3)
  {
	super(n1,n2);
	z=n3;
  } 
  public void showData()
  {
	super.showData();
	System.out.println(z);
  }
}