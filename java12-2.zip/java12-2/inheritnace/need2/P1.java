class P1
{
  public static void main(String []args)
  {
	BB obj=new BB(90,45,78);
	obj.showData();
  }
}