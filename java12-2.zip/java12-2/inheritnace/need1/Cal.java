public class Cal
{
  protected int num1;
  protected int num2;
  protected int res;

  public void acceptNumbers(int n1,int n2)
  {
	num1=n1;
	num2=n2;
  }
  public void showResult()
  {
	System.out.println(res);
  }
}

