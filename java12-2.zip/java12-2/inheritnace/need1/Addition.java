public class Addition extends Cal
{
  public void add()
  {
	res=num1+num2;
  }
}

