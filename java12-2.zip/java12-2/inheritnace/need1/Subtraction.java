public class Subtraction extends Cal
{
  public void subtract()
  {
	res=num1-num2;
  }
}

