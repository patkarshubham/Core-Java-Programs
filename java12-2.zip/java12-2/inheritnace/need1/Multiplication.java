public class Multiplication extends Cal
{
  public void multiply()
  {
	res=num1*num2;
  }
}

