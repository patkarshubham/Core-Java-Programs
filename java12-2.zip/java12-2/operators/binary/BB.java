class BB
{
  public static void main(String []args)
  {
	int x=10;

	boolean y=x==20;

	System.out.println(y);
  }
}



















