class AA
{
  public static void main(String []args)
  {
	int x=10;
	x*=40;
	System.out.println(x);
  }
}






