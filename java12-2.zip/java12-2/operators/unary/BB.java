class BB
{
  public static void main(String []args)
  {
	boolean x=true,y;
	y=!x;
	System.out.println(y);
  }
}






