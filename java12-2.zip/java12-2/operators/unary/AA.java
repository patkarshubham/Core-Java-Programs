class AA
{
  public static void main(String []args)
  {
	int x=10,y;
	y=x++ + x++ + x++;
	System.out.println(y);
  }
}






