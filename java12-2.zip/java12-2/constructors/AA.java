public class AA
{

  public void method1()
  {
	//command
  }
  public void method2()
  {
	//command
  }
}