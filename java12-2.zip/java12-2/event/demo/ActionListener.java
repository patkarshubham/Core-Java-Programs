interface ActionListener
{
  void performTask();
}