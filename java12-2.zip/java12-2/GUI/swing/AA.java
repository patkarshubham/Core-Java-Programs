import javax.swing.*;
class AA
{
  public static void main(String []args)
  {
	JFrame fr=new JFrame();
	fr.setSize(600,400);
	fr.setLocation(100,100);
	fr.setResizable(false);
	fr.setDefaultCloseOperation(0);
	fr.setVisible(true);
  }
}