import javax.swing.*;
class CC extends JFrame
{
  public CC()
  {
	setSize(300,300);
	setLocationRelativeTo(null);
	setResizable(false);
	setDefaultCloseOperation(3);
	setVisible(true);
  }
  public static void main(String []args)
  {
	new CC();
  }
}