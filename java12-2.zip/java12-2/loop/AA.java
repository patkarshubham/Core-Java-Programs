class AA
{
  public static void main(String []args)
  {
	int num=34254346;
	int count=0;
	while(num!=0)
	{
	  num=num/10;
	  count++;
	}
	System.out.println("While counted "+count+" digits");
	num=34254346;
	count=0;
	for(;num!=0;)
	{
	  num=num/10;
	  count++;
	}
	System.out.println("For counted "+count+" digits");
  }
}