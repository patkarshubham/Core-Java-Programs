class BB
{
  public static void main(String []args)
  {
	int [][]num={new int[3],new int[3],new int[3],new int[3],new int[3]};

	int [][]num=new int[5][3];
  }
}