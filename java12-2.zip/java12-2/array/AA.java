class AA
{
  public static void main(String []args)
  {
	int []n={30,50,10,70,50,89,34};
	for(int i=0;i<n.length;i++)
	{
	  System.out.println(n[i]);
	}
  }
}

