import javax.swing.*;
class Va
{
  static int user=1,count=0;
  static String player=null;
  static boolean winnerfound=false;
  static ImageIcon icon1,icon2;
  static JLabel msg=new JLabel("First player turn...");
  static JButton reset=new JButton("RESET");
  static JButton []bt=new JButton[9];
}