import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class TicTacToe extends JFrame
{
  JLabel bg=new JLabel(new ImageIcon(getClass().getResource("images/t2.jpg")));
  JPanel []pa=new JPanel[3];
  JLabel msg=new JLabel("First player turn...");
  JButton reset=new JButton("RESET");
  JButton []bt=new JButton[9];
  ImageIcon icon1=new ImageIcon(getClass().getResource("images/user1.png"));
  ImageIcon icon2=new ImageIcon(getClass().getResource("images/user2.png"));
  int user=1,count=0;
  String player=null;
  boolean winnerfound=false;
  public TicTacToe()
  {
	super("Tic Tac Toe");
	setSize(600,640);
	setLocationRelativeTo(null);
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	setResizable(false);
	add(bg);
	addPanels();
	setVisible(true);
  }
  private void addPanels()
  {
	for(int i=0;i<3;i++)
	{
	  pa[i]=new JPanel();
	  bg.add(pa[i]);
	}
	pa[0].setBounds(100,30,400,40);
	pa[1].setBounds(100,100,400,400);
	pa[2].setBounds(100,530,400,40);
	addInfo();
	addButtons();
  }
  private void addInfo()
  {
	pa[0].add(msg);
	msg.setFont(new Font("elephant",Font.PLAIN,25));
	msg.setForeground(Color.blue);
	pa[2].add(reset);
	reset.addActionListener(new ResetListener());
	pa[2].setOpaque(false);
	reset.setFont(new Font("arial",Font.PLAIN,20));
	reset.setEnabled(false);
  }
  private void addButtons()
  {
	pa[1].setBorder(BorderFactory.createLineBorder(Color.red,4));
	pa[1].setLayout(new GridLayout(3,3));     	
	javax.swing.border.Border b=BorderFactory.createLineBorder(Color.red,2);
	TicListener listener=new TicListener();
	for(int i=0;i<9;i++)
	{
	  bt[i]=new JButton();
	  bt[i].addActionListener(listener);
	  bt[i].setBorder(b);
	  bt[i].setBackground(Color.green);
	  pa[1].add(bt[i]);
	}
  }
  class TicListener implements ActionListener
  {
    public void actionPerformed(ActionEvent evt)
    {
	JButton bc=(JButton)evt.getSource();
	Icon ic=bc.getIcon();
	if(ic!=null || winnerfound)
	  return;
	if(user==1)
	{
	  bc.setIcon(icon1);
	  msg.setText("Second player turn...");
	  user=2;
	  player="First";
	  matchIcon(icon1);
	}
	else if(user==2)
	{
	  bc.setIcon(icon2);
	  msg.setText("First player turn...");
	  user=1;
	  player="Second";
	  matchIcon(icon2);
	}
	count++;
	if(count==9 && !winnerfound)
	{
	  msg.setText("Oooops It's a tie...");
	  msg.setForeground(Color.red);
	}
    }  
    private void matchIcon(ImageIcon icon)
    {
	if(bt[0].getIcon()==icon && bt[1].getIcon()==icon && bt[2].getIcon()==icon)
	  announceWinner(0,1,2);
	if(bt[3].getIcon()==icon && bt[4].getIcon()==icon && bt[5].getIcon()==icon)
	  announceWinner(3,4,5);
	if(bt[6].getIcon()==icon && bt[7].getIcon()==icon && bt[8].getIcon()==icon)
	  announceWinner(6,7,8);
	if(bt[0].getIcon()==icon && bt[3].getIcon()==icon && bt[6].getIcon()==icon)
	  announceWinner(0,3,6);
	if(bt[1].getIcon()==icon && bt[4].getIcon()==icon && bt[7].getIcon()==icon)
	  announceWinner(1,4,7);
	if(bt[2].getIcon()==icon && bt[5].getIcon()==icon && bt[8].getIcon()==icon)
	  announceWinner(2,5,8);
	if(bt[0].getIcon()==icon && bt[4].getIcon()==icon && bt[8].getIcon()==icon)
	  announceWinner(0,4,8);
	if(bt[2].getIcon()==icon && bt[4].getIcon()==icon && bt[6].getIcon()==icon)
	  announceWinner(2,4,6);
    } 
    private void announceWinner(int i1,int i2,int i3)
    {
	  bt[i1].setBackground(Color.yellow);
	  bt[i2].setBackground(Color.yellow);
	  bt[i3].setBackground(Color.yellow);
	  msg.setText(player+" player is winner...");
	  msg.setForeground(Color.green);
	  reset.setEnabled(true);
	  winnerfound=true;
    }
  }
  class ResetListener implements ActionListener
  {
    public void actionPerformed(ActionEvent evt)
    {
	winnerfound=false;
	user=1;
	count=0;
	msg.setText("First player turn...");
	msg.setForeground(Color.blue);
	for(int i=0;i<9;i++)
	{
	  bt[i].setIcon(null);
	  bt[i].setBackground(Color.green);
	}
	reset.setEnabled(false);
    }
  }
  public static void main(String []abc)
  {
	setDefaultLookAndFeelDecorated(true);
	new TicTacToe();
  }
}