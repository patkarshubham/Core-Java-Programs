class FlipCart
{
  public static void main(String []args)
  {
	Shoe obj=new Shoe("Adidas",7000,7,"blue");
	obj.showInfo();
  }
}