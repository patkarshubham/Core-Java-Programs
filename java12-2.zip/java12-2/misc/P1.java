class P1
{
  public static void main(String []args)
  {
	String str="INDIA";
	int n=str.length();
	for(int i=0;i<n;i++)
	{
	  for(int j=0;j<=i;j++)
	  {
		char ch=str.charAt(j);
		System.out.print(ch);
	  }
	  System.out.println();
	}
	for(int i=n-2;i>=0;i--)
	{
	  for(int j=0;j<=i;j++)
	  {
		char ch=str.charAt(j);
		System.out.print(ch);
	  }
	  System.out.println();
	}
  }
}

