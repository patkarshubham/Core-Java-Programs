class AA
{
}
class BB
{
  BB(AA a1)
  {
  }
}
class CC
{
  public CC(BB a1)
  {
  }
  void show()
  {
  }
}
class PP
{
  public static void main(String []args)
  {
	new CC(new BB(new AA())).show();
  }
}



