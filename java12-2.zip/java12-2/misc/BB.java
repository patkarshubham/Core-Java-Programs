class CC
{
}
class AA
{
  static void show(CC a1)
  {
  }
}


class BB
{
  public static void main(String []args)
  {
	CC obj=new CC();
	AA.show(obj);
  }
}

www.javatpoint.com