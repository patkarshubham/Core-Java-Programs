class P1
{
  public static void main(String []args)
  {
	myjava.AA.square(35);
  }
}


