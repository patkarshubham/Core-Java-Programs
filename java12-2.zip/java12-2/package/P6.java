import java.awt.*;
import java.awt.Label;
class P6
{
  Button b1;
  Label b2;
  TextField b3;
  TextArea b4;
  Choice b5;
}

