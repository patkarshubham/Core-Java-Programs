import java.awt.Button;
class P4
{
  Button b1;
  Button b2;
  Button b3;
  Button b4;
  Button b5;
}

