class P3
{
  java.awt.Button b1;
  java.awt.Button b2;
}