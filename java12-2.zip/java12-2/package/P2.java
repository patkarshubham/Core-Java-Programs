import myjava.AA;
class P2
{
  public static void main(String []args)
  {
	AA.square(35);
  }
}


