import java.awt.*;
import java.util.*;
class P7
{
  Button b1;
  String b2;
  TextField b3;
  Object b4;
  Random b5;
  Date b6;
}



