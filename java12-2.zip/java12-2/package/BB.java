import java.util.*;
import java.sql.*;
class BB
{
  public static void main(String []args)
  {
	java.util.Date obj1=new java.util.Date();
	System.out.println(obj1);
	java.sql.Date obj2=new java.sql.Date(1,2,3);
	System.out.println(obj2);
  }
}