import java.lang.System;
class AA
{
  public static void main(String []args)
  {
	System.out.println("Package topic is over...");
  }
}