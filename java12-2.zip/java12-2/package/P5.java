import java.awt.Button;
import java.awt.Label;
import java.awt.TextField;
import java.awt.TextArea;
import java.awt.Choice;
class P5
{
  Button b1;
  Label b2;
  TextField b3;
  TextArea b4;
  Choice b5;
}

