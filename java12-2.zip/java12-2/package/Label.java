class Label
{
}