class AA
{
  public static void main(String []args)
  {
	int num=35;
	if(num%5==0 && num%2==0)
	   System.out.println("Valid");
	else
	   System.out.println("Invalid");
  }
}