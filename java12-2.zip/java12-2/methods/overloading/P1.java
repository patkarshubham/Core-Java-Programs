class P1
{
  public static void main(String []args)
  {
	LargestNum.max(4325.25f,213210.0f);
  }
}