public class Circle extends Shape
{
  private int radius;
  public Circle(int r)
  {
	radius=r;
  }
  public void findArea()
  {
	double area=3.14*radius*radius;
	System.out.println("Area of circle is:"+area);
  }
}