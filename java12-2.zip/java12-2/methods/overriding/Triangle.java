public class Triangle extends Shape
{
  private int base;
  private int height;
  public Triangle(int b,int h)
  {
	base=b;
	height=h;
  }
  public void findArea()
  {
	double area=base*height/2;
	System.out.println("Area of triangle is:"+area);
  }
}