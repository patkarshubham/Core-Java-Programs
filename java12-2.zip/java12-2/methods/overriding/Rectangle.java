public class Rectangle extends Shape
{
  private int length;
  private int breadth;
  public Rectangle(int l,int b)
  {
	length=l;
	breadth=b;
  }
  public void findArea()
  {
	int area=length*breadth;
	System.out.println("Area of rectangle is:"+area);
  }
}