import java.util.*;
class ShapeUser
{
  public static void main(String []args)
  {
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter your choice(1 or 2 or 3):");
	int ch=sc.nextInt();
	Shape sh=null;
	switch(ch)
  	{
	  case 1:
	   System.out.print("Enter radius:");
	   int r=sc.nextInt();
	   sh=new Circle(r);
	   break;
	  case 2:
	   sh=new Rectangle(40,30);
	   break;
	  case 3:
	   sh=new Triangle(60,40);
	   break;
	  default:
	   System.out.println("Wrong choice");
	   return;
	}
	sh.findArea();
  }
}