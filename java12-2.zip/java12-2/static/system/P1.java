class P1
{
  public static void main(String []args)
  {
	MySystem.out.println(70);
	System.out.println(70);
  }
}