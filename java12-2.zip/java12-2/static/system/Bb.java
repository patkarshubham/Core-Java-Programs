class AA
{
  public void println(int num)
  {
	System.out.println(num*num);
  }
}
class MySystem
{
  static AA out=new AA();
}