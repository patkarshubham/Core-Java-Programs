class AA
{
  static int x=90;//static
  int y=70;//non-static
  static void show()
  {
	System.out.println(AA.x);
	AA obj=new AA();
	System.out.println(y);
  }
  public static void main(String []args)
  {
	AA.show();
  }
}






