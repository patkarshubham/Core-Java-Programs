class EE
{
  private int x=90;
  public void show()
  {
	int x=30;
	System.out.println(x);
	System.out.println(this.x);
  }
  public static void main(String []args)
  {
	new EE().show();
  }
}






