class CC
{
  int x;
  static void show1(CC t)
  {
	t.x=10;
	t.x=t.x+90;
	System.out.println(t.x);
  }
  void show2()
  {
	this.x=10;
	this.x=this.x+90;
	System.out.println(this.x);
  }
  public static void main(String []args)
  {
	CC obj=new CC();
	show1(obj);
	obj.show2();
  }
}






