public class DD
{
  private int num1;
  public DD(int n)
  {
	num1=n;
  } 
  void square1()
  {
	int sq=num1*num1;
	System.out.println(sq);
  }
  static void square2(int num2)
  {
	int sq=num2*num2;
	System.out.println(sq);
  }
  public static void main(String []args)
  {
	DD obj=new DD(20);
	obj.square1();
	square2(50);
  }
}






