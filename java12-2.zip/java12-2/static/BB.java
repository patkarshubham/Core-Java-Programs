class BB
{
  int x;
  static void show(BB t)
  {
	t.x=10;
	t.x=t.x+90;
	System.out.println(t.x);
  }
  public static void main(String []args)
  {
	BB obj=new BB();
	show(obj);
  }
}






