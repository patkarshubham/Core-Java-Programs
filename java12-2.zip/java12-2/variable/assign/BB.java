class BB
{
  public static void main(String []args)
  {
	System.out.println((int)'9');
	System.out.println((char)65);
  }
}	

