class BB
{
  public static void main(String []args)
  {
	int x=10;
	int y=4;
	float z=(float)x/y;
	System.out.println(z);
  }
}	