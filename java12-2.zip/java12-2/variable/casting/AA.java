class AA
{
  public static void main(String []args)
  {
	float x;
	x=(float)90.34;
	double y;
	y=90.34f;
  }
}	