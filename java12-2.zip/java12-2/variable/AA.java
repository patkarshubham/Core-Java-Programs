class AA
{
  public static void main(String []args)
  {
	byte v1;
	short v2;
	int v3;
	long v4;
	float v5;
	double v6;
	char v7;
	boolean v8;
	String v9;

	v1=90;
	v2=780;
	v3=43464;
	v4=45436567;
	v5=909.45f;
	v6=6786.34;
	v7='k';
	v8=true;
	v9="8/6 tshkand nard indira nagar luckbow";
  }
}