class BB
{
  static void method1()
  {
 	System.out.println("Method1 called...");
	method2();
  }
  static void method2()
  {
 	System.out.println("Method2 called...");
	method3();
  }
  static void method3()
  {
 	System.out.println("Method3 called...");
  }
  public static void main(String []args)
  {
 	System.out.println("Original main called...");	
	method1();
  }
  public static void main(int []args)
  {
 	System.out.println("Duplicate main called...");	
  }
}



