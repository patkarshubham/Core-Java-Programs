class AA
{
  static void checkNumber(int num)
  {
 	int rem=num%2;
	if(rem==0)
	{
	  System.out.println("Even number");
	}	
	else
	{
	  System.out.println("Odd number");
	}
  }
  public static void main(String []args)
  {
	checkNumber(35);
  }
}



